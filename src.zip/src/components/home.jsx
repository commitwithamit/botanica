import MainBtn from "./buttons";
import play from "../assets/img/play.svg";

function Home() {
    return (
        <section className="banner">
            <div className="site-width row-con">
                <div className="col">
                    <h1>Breath Natural</h1>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                    <div className="btns-con">
                        <MainBtn info={{ name: "Explore", path: "/" }} />
                        <div className="play-con">
                            <span className="play-btn">
                                <img src={play} alt="play video" />
                            </span>
                            View Demo...
                        </div>
                    </div>
                </div>
                <div className="col">
            
                </div>
            </div>
        </section>
    )
}

export default Home;


{/* <iframe width="560" height="315" src="https://www.youtube.com/embed/uSOOO3KBKDY?si=k8K39tAqHiWRTTOB" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe> */}