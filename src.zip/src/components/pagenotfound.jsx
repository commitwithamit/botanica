import svg from "../assets/img/404.svg";
import MainBtn from "./buttons";
function PageNotFound() {
    return (
        <section className="site-width pagenotfound">
            <img src={svg} alt="404 page not found" />
            <div>
                <h3>Oops! This Page is Un-Plant-able!</h3>
                <MainBtn info={{name:"Go to Homepage", path:"/"}}/>
            </div>
        </section>
    )
}

export default PageNotFound;