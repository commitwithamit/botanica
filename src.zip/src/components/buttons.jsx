import bagIcon from '../assets/img/bag.svg';
import {Link} from 'react-router-dom';

function MainBtn(props){
    return(
        <>
            <Link to={props.info.path} className="btns">
                {props.info.name}
            </Link>
        </>
    )
}

export default MainBtn;

export function CartBtn(){
    return(
        <>
            <button className="btn-icon">
                <img src={bagIcon} alt="add to cart"/>
            </button>
        </>
    )
}
