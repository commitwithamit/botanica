import logo from "../assets/img/logo.png";
import carret from "../assets/img/carret.svg";
import bag from "../assets/img/bag.svg";
import search from "../assets/img/search.svg";
import user from "../assets/img/person.svg";
import { Link } from "react-router-dom";
import { useState } from "react";

function Header() {
    const [trigger, setTrigger] = useState(false);
    const [openSearch, setOpenSearch] = useState(false);
    return (
        <header className="site-width">
            <nav>
                <div className="left-part">
                    <Link to="">
                        <img src={logo} alt="Botanica logo" />
                    </Link>
                </div>
                <div className="center-part">
                    <ul>
                        <li>
                            <Link to="">Home</Link>
                        </li>
                        <li className="drop-trigger">
                            <span to="">Plants Type <img src={carret} alt="carret" /></span>
                            <div className="drop-con">
                                <ul className="dropdown">
                                    <li>
                                        <Link to="plants/flowering-houseplants">Flowering Houseplants</Link>
                                    </li>
                                    <li>
                                        <Link to="plants/succulents-cacti">Succulents & Cacti</Link>
                                    </li>
                                    <li>
                                        <Link to="plants/herbs-culinary">Herbs & Culinary</Link>
                                    </li>
                                    <li>
                                        <Link to="plants/bonsai">Bonsai & Miniature</Link>
                                    </li>
                                    <li>
                                        <Link to="plants/foliage">Foliage Plants</Link>
                                    </li>
                                    <li>
                                        <Link to="plants/air-plants">Air Plants (Tillandsia)</Link>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li>
                            <Link to="">More</Link>
                        </li>
                        <li>
                            <Link to="contact-us">Contact</Link>
                        </li>
                    </ul>
                </div>
                <div className="right-part">
                    <div className="search-box">
                        <div className={openSearch ? "open" : ""}>
                            <input type="text" name="serach" />
                        </div>
                        <button>
                            <img src={search} onClick={() => setOpenSearch(!openSearch)} alt="serach icon" />
                        </button>
                    </div>
                    <div>
                        <img src={user} alt="serach icon" />
                    </div>
                    <div>
                        <Link to="cart">
                            <img src={bag} alt="bag icon" />
                        </Link>
                    </div>
                    <div className="mob-menu">
                        <span className={trigger ? "active menu-icon" : "menu-icon"} onClick={() => setTrigger(!trigger)}></span>
                        <div className={trigger ? "active sidebar" : "sidebar"}>
                            <div className="extra-top"></div>
                            <div className="main-bottom">
                                <div className="side-category">
                                    <h3>Plant Types</h3>
                                    <ul>
                                        <li>
                                            <Link to="plants/flowering-houseplants">Flowering Houseplants</Link>
                                        </li>
                                        <li>
                                            <Link to="plants/succulents-cacti">Succulents & Cacti</Link>
                                        </li>
                                        <li>
                                            <Link to="plants/herbs-culinary">Herbs & Culinary</Link>
                                        </li>
                                        <li>
                                            <Link to="plants/bonsai">Bonsai & Miniature</Link>
                                        </li>
                                        <li>
                                            <Link to="plants/foliage">Foliage Plants</Link>
                                        </li>
                                        <li>
                                            <Link to="plants/air-plants">Air Plants (Tillandsia)</Link>
                                        </li>
                                    </ul>
                                </div>
                                <div className="side-nav">
                                    <h3>Quick Links</h3>
                                    <ul>
                                        <li>
                                            <Link to="">Home</Link>
                                        </li>
                                        <li>
                                            <Link to="about-us">About Us</Link>
                                        </li>
                                        <li>
                                            <Link to="contact-us">Contact Us</Link>
                                        </li>
                                    </ul>
                                </div>
                                <div className="side-social">
                                    <Link to="https://www.facebook.com/" target="_blank">FB</Link>
                                    <Link to="https://x.com/" target="_blank">TW</Link>
                                    <Link to="https://www.instagram.com/" target="_blank">IN</Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </header>
    )
}

export default Header;